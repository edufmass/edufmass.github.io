-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2022 at 12:50 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cac2022-22569`
--

-- --------------------------------------------------------

--
-- Table structure for table `db01_obligatorio`
--

CREATE TABLE `db01_obligatorio` (
  `id` int(11) UNSIGNED NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `edad` tinyint(2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `provincia` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `db01_obligatorio`
--

INSERT INTO `db01_obligatorio` (`id`, `nombre`, `apellido`, `edad`, `fecha`, `provincia`) VALUES
(1, 'José', 'Perez', 20, '2022-10-26 22:45:59', 'Chubut'),
(2, 'Martín', 'Carrizo', 25, '2022-10-26 22:45:59', 'Buenos Aires'),
(3, 'Victoria', 'Martinez', 41, '2022-10-26 22:45:59', 'Tucumán'),
(4, 'Gustavo', 'Sanchez', 38, '2022-10-26 22:45:59', 'Buenos Aires'),
(5, 'Marcela', 'Gomez', 36, '2022-10-26 22:45:59', 'Mendoza');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `db01_obligatorio`
--
ALTER TABLE `db01_obligatorio`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db01_obligatorio`
--
ALTER TABLE `db01_obligatorio`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
